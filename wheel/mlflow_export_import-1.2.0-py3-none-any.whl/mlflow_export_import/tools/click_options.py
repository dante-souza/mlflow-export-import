import click

def opt_output_file(function):
    function = click.option("--output-file",
        help="Output file.",
        type=str,
        required=False
    )(function)
    return function

def opt_filter(function):
    function = click.option("--filter",
        help="For OSS MLflow this is a filter for search_model_version(), for Databricks it is for search_registered_models().",
        type=str,
        required=False
    )(function)
    return function

