"""
Download artifacts
"""

import click
import mlflow
from mlflow.artifacts import download_artifacts
from . utils import split_model_uri

client = mlflow.MlflowClient()

def download(artifact_uri, output_dir):
    download_artifacts(artifact_uri, dst_path=output_dir)


@click.command()
@click.option("--artifact-uri",
    help="Artifact URI 'models:/production'",
    type=str,
    required=True
)
@click.option("--output-dir",
    help="Output directory for downloaded model.",
    type=str,
    required=True
)

def main(artifact_uri, output_dir):
    print("Options:")
    for k,v in locals().items(): print(f"  {k}: {v}")
    download(artifact_uri, output_dir)


if __name__ == "__main__":
    main()
