
def split_model_uri(model_uri):
    """
    Splits an MLflow model URI into two parts
      - For models scheme, returns the model name and stage or version, e.g models:/sklearn_wine/production
      - For runs scheme, returns the run ID relative model path, e.g runs:/2079b9ee113b4b6c8ae631790d4c1009/sklearn-model
    :param: Models URI.
    :return: Tuple of model name and stage/version or tuple of run ID and relative model path.
    """
    idx = model_uri.find("/")
    path = model_uri[idx+1:]
    idx = path.find("/")
    return path[:idx], path[idx+1:]
