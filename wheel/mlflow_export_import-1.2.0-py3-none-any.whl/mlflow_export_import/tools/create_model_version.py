# https://mlflow.org/docs/latest/python_api/mlflow.client.html#mlflow.client.MlflowClient.create_model_version

import click
import mlflow
from mlflow_export_import.common.dump_utils import dump_obj

client = mlflow.MlflowClient()

def create_registered_model(model_name):
    try:
        client.create_registered_model(model_name)
    except Exception:
        pass

@click.command()
@click.option("--model", help="Registered model.", type=str, required=True)
@click.option("--source", help="Source URI. Examples are 'models:/mymodel/1' or 'runs:/123/model'.", type=str, required=True)
@click.option("--description", help="Description.", type=str, required=False)

def main(model, source, description):
    " Create a model version from an MLflow model URI."
    print("Options:")
    for k,v in locals().items(): 
        print(f"  {k}: {v}")

    create_registered_model(model_name)
    vr = client.create_model_version(model_name, source, description=description)
    dump_obj(vr)

if __name__ == "__main__":
    main()
