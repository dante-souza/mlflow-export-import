
from . http_client import HttpClient

class RestClient(HttpClient):
    """
    Python wrapper client for MLflow and Databricks REST API methods used.
    """

    def __init__(self, host=None, token=None):
        super().__init__("api", host, token)


    # == MLflow api/2.0/mlflow

    def get_experiment(self, experiment_id):
        """
        GET api/2.0/mlflow/experiments/get
        """
        return self.get("2.0/mlflow/experiments/get", {"experiment_id": experiment_id})

    def get_registered_model(self, model_name):
        """
        GET api/2.0/mlflow/registered-models/get
        """
        return self.get("2.0/mlflow/registered-models/get", {"name": model_name})

    def add_run_log_input(self, run_id, datasets):
        """
        POST api/2.0/mlflow/runs/log-inputs
        """
        data = { "run_id": run_id, "datasets": datasets }
        post("2.0/mlflow/runs/log-inputs", data)


    # == Databricks api/2.0

    def get_registered_model_databricks(self, model_name):
        """
        GET api/2.0/mlflow/databricks/registered-models/get
        """
        return self.get("2.0/mlflow/databricks/registered-models/get", { "name": model_name })

    def list_node_types(self):
        """
        GET api/2.0/clusters/list-node-types
        NOTE: Used by importing_into_databricks
        """
        return self.get("2.0/clusters/list-node-types")

    def mk_workspace_dir(workspace_dir):
        """
        POST api/2.0/workspace/mkdirs
        Create a Databricks workspaces directory for experiment.
        """
        post("2.0/workspace/mkdirs", { "path": workspace_dir })


    # == Databricks Unity Catalog api/2.1

    def get_uc_permissions(self, model_name):
        """
        GET /api/2.1/unity-catalog/permissions/{securable_type}/{full_name}
        """
        return self.get(f"2.1/unity-catalog/permissions/function/{model_name}")

    def get_uc_effective_permissions(self, model_name):
        """
        GET /api/2.1/unity-catalog/effective-permissions/{securable_type}/{full_name}
        """
        return self.get(f"2.1/unity-catalog/effective-permissions/function/{model_name}")

    def udate_uc_permissions(self, model_name):
        # PATCH /api/2.1/unity-catalog/permissions/{securable_type}/{full_name}
        pass


def create_rest_client(mlflow_client):
    creds = mlflow_client._tracking_client.store.get_host_creds()
    return RestClient(creds.host, creds.token)
