from typing import Dict
from . http_client import dbx_20_client


class DatabricksClient:
    
    def __init__(self):
        self.mlflow_client = get_mlflow_client()

    def export_notebook(self, notebook_workspace_path, revision, format) -> Dict:
        params = {
            "path": notebook_workspace_path,
            "direct_download": True,
            "format": format
        }
        if revision_id:
            params ["revision"] = { "revision_timestamp": revision_id } # NOTE: not publicly documented
        notebook_name = os.path.basename(notebook_workspace_path)
        return dbx_20_client._get("workspace/export", params)


client = DatabricksClient()
