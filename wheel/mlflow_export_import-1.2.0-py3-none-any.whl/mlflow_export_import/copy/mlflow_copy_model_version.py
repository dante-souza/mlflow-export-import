# uses new MflflowClient.copy_model_version method
# https://mlflow.org/docs/latest/python_api/mlflow.client.html#mlflow.client.MlflowClient.copy_model_version

import click
import mlflow
from . click_options import (
    opt_src_model,
    opt_src_version,
    opt_dst_model
)
from mlflow_export_import.common import utils, model_utils
from mlflow_export_import.common.model_utils import is_unity_catalog_model, dump_model_version
from mlflow_export_import.common.dump_utils import dump_mlflow_client
from mlflow_export_import.client.client_utils import create_mlflow_client

_logger = utils.getLogger(__name__)

print("mlflow fluent:")
print("  mlflow.tracking_uri: ", mlflow.get_tracking_uri())
print("  mlflow.registry_uri: ", mlflow.get_registry_uri())

def copy(src_model_name, src_version,dst_model_name):
    client = create_mlflow_client()
    dump_mlflow_client(client, ">> CLIENT")
    if is_unity_catalog_model(src_model_name):
        mlflow.set_tracking_uri(client.tracking_uri)
        mlflow.set_registry_uri(client._registry_uri)
    dump_mlflow_client(client, ">> CLIENT")

    src_model_uri = f"models:/{src_model_name}/{src_version}"
    src_vr = client.get_model_version(src_model_name, src_version) 
    dump_model_version(src_vr, "Source Model Version")
    dst_vr = client.copy_model_version(src_model_uri, dst_model_name) 
    dump_model_version(dst_vr, "Destination Model Version")


@click.command()
@opt_src_model
@opt_src_version
@opt_dst_model

def main(src_model, src_version, dst_model):
    print("Options:")
    for k,v in locals().items():
        print(f"  {k}: {v}")
    copy(src_model, src_version, dst_model)

if __name__ == "__main__": 
    main()
