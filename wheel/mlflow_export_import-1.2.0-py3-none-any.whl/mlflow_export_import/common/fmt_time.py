

def run(seconds):
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    #print(f"{hours}:{minutes}:{seconds}")
    print(f"{hours}h {minutes}m {seconds}s")

def run2(seconds):
    minutes, seconds = divmod(seconds, 60)
    if minutes:
        print(f"{minutes}m {seconds}s")
    else:
        print(f"{seconds}s")

run(31045)
run(545)
run(45)

print("--------")
run2(31045)
run2(545)
run2(45)
