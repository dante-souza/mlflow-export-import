import os
import json
import mlflow
from mlflow_export_import import version
import wrapt

__version__ = version.__version__

# monkey patch mlflow.tracking.MlflowClient to return tracking URI in __repr__

def add_repr_to_MlflowClient():
    def custom_repr(self): 
        try:
            return f'{{ "tracking_uri": "{self._tracking_client.tracking_uri}" }}'
        except AttributeError:
            return '{{ "tracking_uri": "?" }}'
    mlflow.client.MlflowClient.__repr__ = custom_repr


add_repr_to_MlflowClient()


@wrapt.patch_function_wrapper('mlflow.utils.rest_utils', '_new_call_endpoint')
def call_endpoint(wrapped, instance, args, kwargs):
    try:
        print(">> WRAP.1: args:", args)
        print(">> WRAP.2: kwargs:", kwargs)
        rv =  wrapped(*args, **kwargs)
        return rv
    except Exception as e:
        raise

@wrapt.patch_function_wrapper('mlflow.utils.rest_utils', 'call_endpoint')
def call_endpoint(wrapped, instance, args, kwargs):
    try:
        print(">> WRAP2.1: args:", args)
        print(">> WRAP2.2: kwargs:", kwargs)
        rv =  wrapped(*args, **kwargs)
        return rv
    except Exception as e:
        raise

print(">> __init__.py:")

def call_me():
    from mlflow.utils import rest_utils
    import mlflow
    print(">> call_me")
    client = mlflow.MlflowClient()
    print(">> call_me: client:",client)
    exp = client.get_experiment_by_name("sklearn_wine_best")
    print(">> call_me: exp:",exp)

    uri = "http://localhost:5020/api/2.0/mlflow/metrics/get-history"
    params = { "experiment_name": "sklearn_wine_best" }
    exp = rest_utils.new_call_endpoint("get", uri, params)
    #exp = call_endpoint("get", uri, params)
    #print(">> call_me: exp.2:",exp)
    
